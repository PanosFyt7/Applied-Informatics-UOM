package com.example.r7;

public class Provision {
    private String id;
    private String proname;
    private String provisionCode;

    public Provision(String id, String proname, String provisionCode) {
        this.id = id;
        this.proname = proname;
        this.provisionCode = provisionCode;
    }

    public String getId() {
        return id;
    }

    public String getProname() {
        return proname;
    }

    public String getProvisionCode() {
        return provisionCode;
    }

}
