package com.example.r7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class Register extends AppCompatActivity {

    private final String myIP = "192.168.1.8";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); // krivei to  title banner
        setContentView(R.layout.activity_register);


        EditText nameEditText = findViewById(R.id.nameEditText);
        EditText amkaEditText = findViewById(R.id.amkaEditText);
        EditText addressEditText = findViewById(R.id.addressEditText);
        EditText emailEditText = findViewById(R.id.emailEditText);
        EditText usernameEditText = findViewById(R.id.usernameEditText);
        EditText passEditText = findViewById(R.id.passwordEditText);

        //λειτουργικότητα του register button
        Button registerButton = findViewById(R.id.registerButton);
        registerButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                OkHttpHandler okHttpHandler = new OkHttpHandler();
                String name = String.valueOf(nameEditText.getText());
                String amka = String.valueOf(amkaEditText.getText());
                String address = String.valueOf(addressEditText.getText());
                String email = String.valueOf(emailEditText.getText());
                String username = String.valueOf(usernameEditText.getText());
                String password = String.valueOf(passEditText.getText());

                if (name.isEmpty() || amka.isEmpty() | address.isEmpty() || email.isEmpty() || username.isEmpty() || password.isEmpty()) {
                    // Show a toast message indicating incomplete data
                    Toast.makeText(getApplicationContext(), "Συμπληρώστε όλα τα πεδία",
                            Toast.LENGTH_SHORT).show();
                }else if(!isNumeric(amka)) {
                    // Show a toast message indicating invalid input
                    Toast.makeText(getApplicationContext(), "Ο ΑΜΚΑ πρέπει να αποτελείται μόνο από αριθμούς",
                            Toast.LENGTH_SHORT).show();
                }else if (!isValidEmail(email)) {
                    // Show a toast message indicating invalid email format
                    Toast.makeText(getApplicationContext(), "Λάθος μορφή email",
                            Toast.LENGTH_SHORT).show();
                }else{
                    String url= "http://"+myIP+"/physiotherapp/registerPatient.php?name=" + name
                            + "&amka=" + amka + "&address=" + address + "&email=" + email + "&username=" + username + "&password=" + password;
                    try{
                        okHttpHandler.registerPatient(url);
                        Toast.makeText(getApplicationContext(), "Πραγματοποιήθηκε η εγγραφή",
                                Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(Register.this, LogIn.class);
                        startActivity(intent);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }



            }
        });
    }


    private boolean isNumeric(String str) {
        return str.matches("-?\\d+(\\.\\d+)?"); // Regex pattern to match numbers
    }

    private boolean isValidEmail(String email) {
        String emailPattern = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.(?:[a-zA-Z]{2,4}(?:\\.[a-zA-Z]{2})?)$";
        int dotCount = email.length() - email.replace(".", "").length();
        return email.matches(emailPattern) && dotCount <= 2 && !email.endsWith(".");
    }

}