package com.example.r7;
import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class InsertDataAsyncTask extends AsyncTask<String, Void, Void> {

    @Override
    protected Void doInBackground(String... params) {
        // Extract the data from params
        String nameData = params[0];
        String addressData = params[1];
        String afmData = params[2];
        String usernameData = params[3];
        String passwordData = params[4];

        // Define the server API URL
        String serverUrl = "http://192.168.1.8/physiotherapp/createPhysioCenter.php";

        // Make an HTTP POST request to the server API
        try {
            URL url = new URL(serverUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);

            // Pass the data to be inserted as form parameters or in JSON format
            String namePostData = "name=" + URLEncoder.encode(nameData, "UTF-8");
            String addressPostData = "address=" + URLEncoder.encode(addressData, "UTF-8");
            String afmPostData = "afm=" + URLEncoder.encode(afmData, "UTF-8");
            String usernamePostData = "username=" + URLEncoder.encode(usernameData, "UTF-8");
            String passwordPostData = "password=" + URLEncoder.encode(passwordData, "UTF-8");

            // Write the data to the server
            OutputStream outputStream = connection.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));

            writer.write(namePostData + "&" + addressPostData + "&" + afmPostData + "&" + usernamePostData + "&" + passwordPostData);
            writer.flush();
            writer.close();
            outputStream.close();

            // Read the server's response
            int responseCode = connection.getResponseCode();
            // Handle the response as needed

            connection.disconnect();
        }catch (IOException e) {
            // Log the error details
            Log.e("InsertData", "Error occurred: " + e.getMessage(), e);
        }

        return null;
    }
}

