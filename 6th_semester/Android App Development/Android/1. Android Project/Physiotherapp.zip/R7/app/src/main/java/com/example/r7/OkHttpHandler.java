package com.example.r7;

import android.os.StrictMode;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.*;


public class OkHttpHandler {

    User user;
    public OkHttpHandler() {
        StrictMode.ThreadPolicy policy = new
                StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }
    //μέθοδος για να σύγκριση credentials για να αποφασίσουμε ποια αρχική θα εμφανιστεί
    //Επιστρέφει ένα αντικείμενο User με id_role, το όνομα και το id του (είτε ασθενή, είτε ιατρείο) με βάση τι role_id έχει
    public User checkCredentials(String url) throws Exception{
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("",
                MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST", body).build();
        Response response = client.newCall(request).execute();
        String data = response.body().string();
        System.out.println("My Response: " + response);

        String roleString;
        int roleID = 3;
        String name = "";
        String idString;
        int id = 0;
       try{
           JSONObject json = new JSONObject(data);
           roleString = json.getString("id_role");
           roleID = Integer.parseInt((roleString));
           name  = json.getString("name");
           idString = json.getString("id");
           id = Integer.parseInt(idString);
           user = new User(roleID,name, id);
       } catch (JSONException e){
           e.printStackTrace();
       }
        return user ;
    }
    //μέθοδος για να κάνει εγγραφή ένας patient
    public void registerPatient(String url) throws IOException {
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("",
                MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST", body).build();
        Response response = client.newCall(request).execute();
        System.out.println("My Response: " + response);
        }

    //μέθοδος που καλεί το createProvision.php για να δημιουργήσει μια νέα Παροχή (R2)
    public void createProvision(String url) throws Exception {
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("",
                MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST",
                body).build();
        Response response = client.newCall(request).execute();
        System.out.println("My Response: " + response);
    }

    //μέθοδος που καλεί το getSessions.php για να ψάχνει έναν ασθεή και να επιστρέφει το ιστορικό του (R4)
    ArrayList<Session> getSessions(String url) throws Exception{
        ArrayList<Session> sessionList = new ArrayList<>(); //λίστα java που θα αποθηκεύει τα αντικείμενα json που λαμβάνουμε
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("", MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST", body).build();
        Response response = client.newCall(request).execute();
        String data = response.body().string(); //το string response που λαμβάνουμε
        System.out.println("My Response: " + data);

        try{
            JSONObject json = new JSONObject(data);
            Iterator<String> keys = json.keys();
            while(keys.hasNext()){
                String sessionID = keys.next();
                String patientName = json.getJSONObject(sessionID).getString("name").toString();
                String provisionName = json.getJSONObject(sessionID).getString("proname").toString();
                String date = json.getJSONObject(sessionID).getString("date").toString();
                String provisionCost = json.getJSONObject(sessionID).getString("cost").toString();

                Session session = new Session(sessionID, patientName, provisionName, provisionCost, date);
                sessionList.add(session);
            }
        }
        catch(JSONException e){
            e.printStackTrace();
            Session nullSession = new Session("0", "0", "0", "0", "0");
            sessionList.add(nullSession);
        }
        return sessionList;
    }

    //μέθοδος που καλέι το getAppointmentPlan.php για να φέρει τα ραντεβού της επιλεγμένης ημέρας (R6)
    public ArrayList<Appointment> getAppointmentPlan(String url) throws Exception{
        ArrayList<Appointment> appointmentList = new ArrayList<>();
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("", MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST", body).build();
        Response response = client.newCall(request).execute();
        String data = response.body().string();
        System.out.println("My Response: " + data);

        try{
            JSONObject json = new JSONObject(data);
            Iterator<String> keys = json.keys();
            while(keys.hasNext()){
                String appointmentID = keys.next();
                String time = json.getJSONObject(appointmentID).getString("time").toString();
                String name = json.getJSONObject(appointmentID).getString("name").toString();

                String cutTime = time.substring(0,5);
                Appointment appointment = new Appointment(appointmentID, cutTime, name);
                appointmentList.add(appointment);
            }
        }
        catch(JSONException e){
            e.printStackTrace();
        }
        return appointmentList;
    }

    //μέθοδος που καλεί το getAppointments.php για να επιστρέφει τα ραντεβού (R7)
    ArrayList<Appointment> getAppointments(String url) throws Exception{
        ArrayList<Appointment> appointmentList = new ArrayList<>(); //λίστα java που θα αποθηκεύει τα αντικείμενα json που λαμβάνουμε
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("", MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST", body).build();
        Response response = client.newCall(request).execute();
        String data = response.body().string(); //το string response που λαμβάνουμε
        System.out.println("My Response: " + data);

        try{
            JSONObject json = new JSONObject(data);
            Iterator<String> keys = json.keys();
            while(keys.hasNext()){
                String appointmentId = keys.next();
                String name = json.getJSONObject(appointmentId).getString("name").toString();
                String mobile = json.getJSONObject(appointmentId).getString("phonenumber").toString();
                String date = json.getJSONObject(appointmentId).getString("date").toString();
                String time = json.getJSONObject(appointmentId).getString("time").toString();
                String appointmentStatus = json.getJSONObject(appointmentId).getString("appointment_status").toString();

                // διαδικασία για απαλοιφή από τα milisecs
                SimpleDateFormat inputFormat = new SimpleDateFormat("HH:mm:ss.SSSSSS");
                SimpleDateFormat outputFormat = new SimpleDateFormat("HH:mm");
                try{
                    Date parsedTime = inputFormat.parse(time);
                    String formattedTime = outputFormat.format(parsedTime);

                    String[] timeComponents = formattedTime.split(":");
                    String hours = timeComponents[0];
                    String minutes = timeComponents[1];

                    time = hours + ":" + minutes; // αυτή είναι η σωστή μορφή του time
                } catch (ParseException e){
                    e.printStackTrace();
                }

                Appointment appointment = new Appointment(appointmentId, name, mobile, date, time, appointmentStatus);
                appointmentList.add(appointment);
            }
        }
        catch(JSONException e){
            e.printStackTrace();
        }
        return appointmentList;
    }

    //μέθοδος που καλεί το setAppointmentStatus.php για να βγάζει από τη λίστα τα αποδεκτά ή απορριφθέντα ραντεβού (R7)
    public void setAppointmentStatus(String url) throws Exception{
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("", MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST", body).build();
        Response response = client.newCall(request).execute();
        System.out.println("My Response: " + response);
    }

    //μέθοδος που καλεί το getDailyAppointments.php για να φέρνει τα αποδεκτά ραντεβού της επιλεγμένης ημέρας (R8)
    public ArrayList<Appointment> getDailyAppointments(String url) throws Exception{
        ArrayList<Appointment> appointmentList = new ArrayList<>();
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("", MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST", body).build();
        Response response = client.newCall(request).execute();
        String data = response.body().string();
        System.out.println("My Response: " + data);

        try{
            JSONObject json = new JSONObject(data);
            Iterator<String> keys = json.keys();
            while(keys.hasNext()){
                String appointmentID = keys.next();
                String time = json.getJSONObject(appointmentID).getString("time").toString();
                String name = json.getJSONObject(appointmentID).getString("name").toString();

                String cutTime = time.substring(0,5);
                Appointment appointment = new Appointment(appointmentID, cutTime, name);
                appointmentList.add(appointment);
            }
        }
        catch(JSONException e){
            e.printStackTrace();
        }
        return appointmentList;
    }

    //μέθοδος που καλεί το getPovisions.php για να φέρνει τα provisions (R8)

    public ArrayList<Provision> getProvisions(String url) throws Exception{
        ArrayList<Provision> provisionList = new ArrayList<>();
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("", MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST", body).build();
        Response response = client.newCall(request).execute();
        String data = response.body().string();
        System.out.println("My Response: " + data);
        try{
            JSONObject json = new JSONObject(data);
            Iterator<String> keys = json.keys();
            while(keys.hasNext()){
                String provisionId = keys.next();
                String provisionName = json.getJSONObject(provisionId).getString("proname").toString();
                String provisionCode = json.getJSONObject(provisionId).getString("id_provision").toString();

                Provision provision = new Provision(provisionId, provisionName, provisionCode);
                provisionList.add(provision);
            }
        }
        catch(JSONException e){
            e.printStackTrace();
        }
        return provisionList;

    }

    //μέθοδος που καλεί το createSessions.php για να δημιουργεί ένα session (R8)
    public void createSession(String url) throws Exception{
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("", MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST", body).build();
        Response response = client.newCall(request).execute();
        System.out.println("My Response: " + response);
    }

    //μέθοδος που καλεί το getCenters.php για να φέρνει τα κέντρα για να τα βάλει στο dropdownlist (R9)
    public ArrayList<Center> getCenters(String url) throws Exception{
        ArrayList<Center> centerList = new ArrayList<>();
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("", MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST", body).build();
        Response response = client.newCall(request).execute();
        String data = response.body().string();
        System.out.println("My Response: " + data);
        try{
            JSONObject json = new JSONObject(data);
            Iterator<String> keys = json.keys();
            while(keys.hasNext()){
                String centerId = keys.next();
                String centerName = json.getJSONObject(centerId).getString("phyname").toString();

                Center center = new Center(centerId, centerName);
                centerList.add(center);
            }
        }
        catch(JSONException e){
            e.printStackTrace();
        }
        return centerList;
    }

    //μέθοδος για να στείλει το αίτημα ρανεβού στην βάση δεδομένων (R9)
    public void sendAppointmentData(String url) throws Exception {
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("",
                MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST",
                body).build();
        Response response = client.newCall(request).execute();
        System.out.println("My Response: " + response);
    }


    //μέθοδος που καλέι το getEconomicHistory.php για να φέρνει από την βάση το ιστορικό του ασθενή (R10)
    ArrayList<Session> getEconomicHistory(String url) throws Exception{
        ArrayList<Session> sessionList = new ArrayList<>(); //λίστα java που θα αποθηκεύει τα αντικείμενα json που λαμβάνουμε
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("", MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST", body).build();
        Response response = client.newCall(request).execute();
        String data = response.body().string(); //το string response που λαμβάνουμε
        System.out.println("My Response: " + data);

        try{
            JSONObject json = new JSONObject(data);
            Iterator<String> keys = json.keys();
            while(keys.hasNext()){
                String sessionID = keys.next();
                String patientName = json.getJSONObject(sessionID).getString("name").toString();
                String provisionName = json.getJSONObject(sessionID).getString("proname").toString();
                String cost = json.getJSONObject(sessionID).getString("cost").toString();
                String date = json.getJSONObject(sessionID).getString("date").toString();
                String centerName = json.getJSONObject(sessionID).getString("phyname").toString();

                Session session = new Session(sessionID, patientName, provisionName, cost, date, centerName);
                sessionList.add(session);
            }
        }
        catch(JSONException e){
            e.printStackTrace();
        }
        return sessionList;
    }



}
