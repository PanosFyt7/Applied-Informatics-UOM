package com.example.r7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class r5b extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); // κρύβει το του banner τίτλου
        setContentView(R.layout.activity_r5b);

        Intent intent = getIntent();
        String name = intent.getStringExtra("patientName");
        String amka = intent.getStringExtra("amka");
        String address = intent.getStringExtra("address");
        String mobile = intent.getStringExtra("mobile");
        String email = intent.getStringExtra("email");
        String centerName = intent.getStringExtra("NAME");
        int centerID = intent.getIntExtra("ID", 0);

        TextView patient_name = findViewById(R.id.patient_name);
        patient_name.setText(name);

        TextView patient_amka = findViewById(R.id.patient_amka);
        patient_amka.setText(amka);

        TextView patient_address = findViewById(R.id.patient_address);
        patient_address.setText(address);

        TextView patient_mobile = findViewById(R.id.patient_mobile);
        patient_mobile.setText(mobile);

        TextView patient_email = findViewById(R.id.patient_email);
        patient_email.setText(email);

        //λειτουργικότητα για το patient History Button
        Button patientHistoryButton = findViewById(R.id.patient_history_button);
        patientHistoryButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r5b.this, r4.class);
                intent.putExtra("NAME", centerName);
                intent.putExtra("ID", centerID);
                int amkaInt = Integer.parseInt(amka);
                intent.putExtra("patientAMKA", amkaInt);
                startActivity(intent);
            }
        });
        //λειτουργικότητα για το home button
        ImageButton homeButton = findViewById(R.id.homeImgButton);
        homeButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r5b.this, CenterHome.class);
                intent.putExtra("NAME", centerName);
                intent.putExtra("ID", centerID);
                startActivity(intent);
            }
        });

        //λειτουργικότητα για το logoff Button
        Button logoffButton = findViewById(R.id.logOffBtn);
        logoffButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r5b.this, LogIn.class);
                startActivity(intent);
            }
        });




    }
}