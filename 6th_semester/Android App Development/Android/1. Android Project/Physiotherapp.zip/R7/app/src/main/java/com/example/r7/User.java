package com.example.r7;

public class User {

    private String name;
    private int idRole;
    private int id;

    public User(int idRole, String name, int id){
        this.name = name;
        this.idRole = idRole;
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getIdRole() {
        return idRole;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setIdRole(int idRole) {
        this.idRole = idRole;
    }


}
