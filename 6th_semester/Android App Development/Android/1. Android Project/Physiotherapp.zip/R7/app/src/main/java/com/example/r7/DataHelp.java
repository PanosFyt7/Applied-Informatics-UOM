package com.example.r7;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class DataHelp extends AsyncTask<String, Void, Void> {
    private Context context;

    public DataHelp(Context context) {
        this.context = context;
    }

    @Override
    protected Void doInBackground(String... params) {
        // Extract the data from params
        String nameData = params[0];
        String addressData = params[1];
        String amkaData = params[2];
        String phoneData = params[3];
        String emailData = params[4];

        // Check if any of the fields is empty
        if (nameData.isEmpty() || addressData.isEmpty() || amkaData.isEmpty() || phoneData.isEmpty() || emailData.isEmpty()) {
            // Show a toast message indicating incomplete data
            showToast("Please fill all the fields");
            return null; // Return early without making the request
        }

        // Check if "amka" contains only numbers
        if (!isNumeric(amkaData)) {
            // Show a toast message indicating invalid input
            showToast("AMKA should contain only numbers");
            return null; // Return early without making the request
        }

        // Check if "phone" contains only numbers
        if (!isNumeric(phoneData)) {
            // Show a toast message indicating invalid input
            showToast("Phone should contain only numbers");
            return null; // Return early without making the request
        }

        // Check if "email" has a valid format
        if (!isValidEmail(emailData)) {
            // Show a toast message indicating invalid email format
            showToast("Invalid email format");
            return null; // Return early without making the request
        }

        // Define the server API URL
        String serverUrl = "http://192.168.1.8/physiotherapp/createPatient.php";

        // Make an HTTP POST request to the server API
        try {
            URL url = new URL(serverUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);

            // Pass the data to be inserted as form parameters or in JSON format
            String namePostData = "name=" + URLEncoder.encode(nameData, "UTF-8");
            String addressPostData = "address=" + URLEncoder.encode(addressData, "UTF-8");
            String amkaPostData = "amka=" + URLEncoder.encode(amkaData, "UTF-8");
            String phonePostData = "phone=" + URLEncoder.encode(phoneData, "UTF-8");
            String emailPostData = "email=" + URLEncoder.encode(emailData, "UTF-8");

            // Write the data to the server
            OutputStream outputStream = connection.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
            writer.write(namePostData + "&" + addressPostData + "&" + amkaPostData + "&" + phonePostData + "&" + emailPostData);
            writer.flush();
            writer.close();
            outputStream.close();

            // Read the server's response
            int responseCode = connection.getResponseCode();
            connection.disconnect();
        } catch (IOException e) {
            // Log the error details
            Log.e("InsertData", "Error occurred: " + e.getMessage(), e);
        }

        // Show a toast message indicating successful data insertion
        showToast("Data Inserted Successfully");

        return null;
    }

    private void showToast(final String message) {
        ((r3) context).runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean isNumeric(String str) {
        return str.matches("-?\\d+(\\.\\d+)?"); // Regex pattern to match numbers
    }

    private boolean isValidEmail(String email) {
        String emailPattern = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.(?:[a-zA-Z]{2,4}(?:\\.[a-zA-Z]{2})?)$";
        int dotCount = email.length() - email.replace(".", "").length();
        return email.matches(emailPattern) && dotCount <= 2 && !email.endsWith(".");
    }

}
