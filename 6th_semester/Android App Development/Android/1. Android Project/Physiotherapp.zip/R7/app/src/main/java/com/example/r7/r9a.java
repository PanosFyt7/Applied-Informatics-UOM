package com.example.r7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class r9a extends AppCompatActivity {
    TextView check;
    EditText editTextTextPersonName;
    EditText editTextTextPersonName2;
    EditText editTextTextPersonName4;
    EditText editTextTextPersonName5;

    Spinner spinner;

   private SharedPreferences sharedPreferences;
//    int visitCount;

    //String checkedCheckboxText;

    ArrayList<Center> CenterList = new ArrayList<Center>();

    String selectedCenterID = "";
    String selectedName = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_r9a);

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        // Retrieve the visit count from SharedPreferences
//        visitCount = sharedPreferences.getInt("visitCount", 0);


        Intent intent = getIntent();
        String patientName = intent.getStringExtra("NAME");
        int patientID = intent.getIntExtra("ID", 0);
        int fores = intent.getIntExtra("fores",0);
        String checkedCheckboxText = intent.getStringExtra("checked_checkbox_text");

        //λειτουργικότητα για το home button
        ImageButton homeButton = findViewById(R.id.homeImgButton);
        homeButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r9a.this, PatientHome.class);
                intent.putExtra("NAME", patientName);
                intent.putExtra("ID", patientID);
                startActivity(intent);
            }
        });

        //λειτουργικότητα για το logoff Button
        Button logoffButton = findViewById(R.id.logOffBtn);
        logoffButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r9a.this, LogIn.class);
                startActivity(intent);
            }
        });


        editTextTextPersonName = findViewById(R.id.editTextTextPersonName);
        editTextTextPersonName2 = findViewById(R.id.editTextTextPersonName2);
        editTextTextPersonName4 = findViewById(R.id.editTextTextPersonName4);
        editTextTextPersonName5 = findViewById(R.id.editTextTextPersonName5);
        spinner = findViewById(R.id.spinner);

        populateDropdown();

        if(fores==1) {
            editTextTextPersonName.setText(intent.getStringExtra("phone_num"));
            editTextTextPersonName2.setText(intent.getStringExtra("day"));
            editTextTextPersonName4.setText(intent.getStringExtra("month"));
            editTextTextPersonName5.setText(intent.getStringExtra("year"));

            String selectedSpinnerValue = intent.getStringExtra("physioName");
            int index = getIndexForValue(selectedSpinnerValue);
            spinner.setSelection(index);
        }

        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Get the entered values
                String text1 = editTextTextPersonName.getText().toString();
                String text2 = editTextTextPersonName2.getText().toString();
                String text4 = editTextTextPersonName4.getText().toString();
                String text5 = editTextTextPersonName5.getText().toString();
                String selectedText = spinner.getSelectedItem().toString();

                Intent intent = getIntent();
                String checkedCheckboxText = intent.getStringExtra("checked_checkbox_text");

                // Combine the date components
                String combined_date = text5 + "-" + text4 + "-" + text2;
                // check.setText(checkedCheckboxText);

                String url = "http://192.168.1.8/physiotherapp/createAppointmentRequest.php?id=" + patientID + "&phone_num=" + text1+ "&physio=" + selectedText+
                        "&date=" + combined_date + "&checkbox_text=" + checkedCheckboxText + "&centerID=" + selectedCenterID;

                // Send the data to the database
                try {
                    OkHttpHandler Handler = new OkHttpHandler();
                    Handler.sendAppointmentData(url);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.clear();
                    editor.apply();
                    Toast.makeText(getApplicationContext(), "Το αίτημα αποστάλθηκε με επιτυχία",
                            Toast.LENGTH_SHORT).show();
                } catch(Exception e){
                    e.printStackTrace();
                }

            }

        });

        Button button3 = findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){

                // Get the entered values
                String text1 = editTextTextPersonName.getText().toString();
                String text2 = editTextTextPersonName2.getText().toString();
                String text4 = editTextTextPersonName4.getText().toString();
                String text5 = editTextTextPersonName5.getText().toString();
                String selectedText = spinner.getSelectedItem().toString();

                Intent intent = new Intent(r9a.this, r9b.class);
                intent.putExtra("phone_num", text1);
                intent.putExtra("day", text2);
                intent.putExtra("month", text4);
                intent.putExtra("year", text5);
                intent.putExtra("fores", fores);
                intent.putExtra("physioName", selectedName);
                intent.putExtra("NAME", patientName);
                intent.putExtra("ID", patientID);

                startActivity(intent);

            }


        });

    }

    public void populateDropdown() {
        Spinner provisionSpinner = findViewById(R.id.spinner);
        String url = "http://192.168.1.8/physiotherapp/getCenters.php";

        try {
            OkHttpHandler okHttpHandler = new OkHttpHandler();
            CenterList = okHttpHandler.getCenters(url);
            ArrayList<String> physioNames = new ArrayList<String>();

            for (Center center : CenterList) {
                String physioName = center.getPhyName();
                physioNames.add(physioName);
            }

            //για να τα βάλει στο spinner
            ArrayAdapter<String> adapter = new ArrayAdapter<>(r9a.this, android.R.layout.simple_spinner_item, physioNames);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            provisionSpinner.setAdapter(adapter);

            provisionSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    selectedName = parent.getSelectedItem().toString();

                    for (Center center : CenterList) {
                        if (center.getPhyName().equals(selectedName)) {
                            selectedCenterID = center.getId();
                            break;
                        }
                    }
                }
                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    // Handle the case where nothing is selected

                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private int getIndexForValue(String value) {
        ArrayAdapter<String> adapter = (ArrayAdapter<String>) spinner.getAdapter();
        int count = adapter.getCount();

        for (int i = 0; i < count; i++) {
            if (adapter.getItem(i).equals(value)) {
                return i;
            }
        }

        return 0; // Default to the first item if value is not found
    }

}
