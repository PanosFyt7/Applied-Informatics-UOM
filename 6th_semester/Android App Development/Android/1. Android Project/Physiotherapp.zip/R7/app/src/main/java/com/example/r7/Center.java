package com.example.r7;

public class Center {


    private String id;
    private String phyName;

    public Center(String id, String phyName) {
        this.id = id;
        this.phyName = phyName;
    }

    public String getId() {
        return id;
    }

    public String getPhyName() {
        return phyName;
    }

}
