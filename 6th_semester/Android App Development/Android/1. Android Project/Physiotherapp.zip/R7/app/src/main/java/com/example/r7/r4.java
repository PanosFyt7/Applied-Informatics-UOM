package com.example.r7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class r4 extends AppCompatActivity {

    private final String myIP = "192.168.1.8";
    private ArrayList<Session> sessions = new ArrayList<Session>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); // κρύβει το του banner τίτλου
        setContentView(R.layout.activity_r4);

        Intent intent = getIntent();
        String centerName = intent.getStringExtra("NAME");
        int centerID = intent.getIntExtra("ID", 0);
        int patientAMKA = intent.getIntExtra("patientAMKA", 0);

        if(patientAMKA != 0){
            String patientAMKAString = "" + patientAMKA;
            createHistoryTable(patientAMKAString);
        }
        else{
            hideHistoryViews();
        }

        //λειτουργικότητα για το searchButton
        Button searchButton = findViewById(R.id.searchButton);
        searchButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){

                EditText searchText = findViewById(R.id.searchText);
                String amka = searchText.getText().toString();
                createHistoryTable(amka);
           }
        });


        //λειτουργικότητα για το home button
        ImageButton homeButton = findViewById(R.id.homeImgButton);
        homeButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r4.this, CenterHome.class);
                intent.putExtra("NAME", centerName);
                intent.putExtra("ID", centerID);
                startActivity(intent);
            }
        });

        //λειτουργικότητα για το logoff Button
        Button logoffButton = findViewById(R.id.logOffBtn);
        logoffButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r4.this, LogIn.class);
                startActivity(intent);
            }
        });
    }

    // μέθοδος για δημιουργία textview με τις κατάλληλες παραμέτρους
    private TextView createDataCell(String text, int layoutWeight) {
        TextView textView = new TextView(this);
        textView.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, layoutWeight));
        textView.setText(text);
        textView.setPadding(5,5,5,5);
        textView.setGravity(Gravity.CENTER);
        return textView;
    }
    public void hideHistoryViews(){
        TableLayout tablelist;
        tablelist = findViewById(R.id.tableHeader);
        tablelist.setVisibility(View.GONE);

        TableLayout tabledata;
        tabledata = findViewById(R.id.tableDataLayout);
        tabledata.setVisibility(View.GONE);

        TextView errorTextView = findViewById(R.id.errorTextView);
        errorTextView.setVisibility(View.GONE);
    }
    public void showHistoryViews(){
        TableLayout tablelist;
        tablelist = findViewById(R.id.tableHeader);
        tablelist.setVisibility(View.VISIBLE);
        TableLayout tabledata;
        tabledata = findViewById(R.id.tableDataLayout);
        tabledata.setVisibility(View.VISIBLE);
    }

    public void createHistoryTable(String amka){
        String url = "http://" + myIP + "/physiotherapp/getSessions.php?amka=" + amka;
        TableLayout tableLayout = findViewById(R.id.tableDataLayout);
        tableLayout.removeAllViews();
        hideHistoryViews();

        try{
            OkHttpHandler okHttpHandler = new OkHttpHandler();
            sessions = okHttpHandler.getSessions(url);
            if(sessions.get(0).getSessionID() != "0"){
                showHistoryViews();
                for (Session session : sessions) {
                    TableRow tableRow = new TableRow(this);
                    tableRow.setLayoutParams(new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));

                    String name = session.getPatientName();
                    String date = session.getDate();
                    String provisionName = session.getProvisonName();
                    String provisionCost = session.getProvisionCost();

                    //δυναμική δημιουργία αντικειμένων για να μπουν στο table row
                    TextView nameTextView = createDataCell(name, 2);
                    TextView dateTextView = createDataCell(date, 2);
                    TextView provisionNameTextView = createDataCell(provisionName, 2);
                    TextView provisionCostTextView = createDataCell(provisionCost, 2);

                    //προσθήκη των view στο row
                    tableRow.addView(nameTextView);
                    tableRow.addView(dateTextView);
                    tableRow.addView(provisionNameTextView);
                    tableRow.addView(provisionCostTextView);

                    //προσθήκη table row στο table
                    tableLayout.addView(tableRow);
                }
            }
            else{
                TextView errorTextView = findViewById(R.id.errorTextView);
                errorTextView.setVisibility(View.VISIBLE);
            }

        } catch(Exception e){
            e.printStackTrace();
        }

    }
}