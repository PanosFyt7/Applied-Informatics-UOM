package com.example.r7;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class r7 extends AppCompatActivity {

    //private AppointmentList appointments;
    private ArrayList<Appointment> appointments = new ArrayList<Appointment>();
    private final String myIP = "192.168.1.8";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); // κρύβει το του banner τίτλου
        setContentView(R.layout.activity_r7);

        //λαμβάνει από το προημούμενο activity το centerID για να εμφανίσει ΜΟΝΟ τα αιτήματα του συγκεκριμένου ιατρείου
        Intent intent = getIntent();
        String centerName = intent.getStringExtra("NAME");
        int centerID = intent.getIntExtra("ID", 0);

        //λειτουργικότητα για το home button
        ImageButton homeButton = findViewById(R.id.homeImgButton);
        homeButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r7.this, CenterHome.class);
                intent.putExtra("NAME", centerName);
                intent.putExtra("ID", centerID);
                startActivity(intent);
            }
        });

        //λειτουργικότητα για το logoff Button
        Button logoffButton = findViewById(R.id.logOffBtn);
        logoffButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r7.this, LogIn.class);
                startActivity(intent);
            }
        });

        //λειτουργικότητα για το r6Button
        Button r6Button = findViewById(R.id.r6Button);
        r6Button.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r7.this, r6a.class);
                intent.putExtra("NAME", centerName);
                intent.putExtra("ID", centerID);
                startActivity(intent);
            }
        });

        //λειτουργικότητα με το φόρτωμα της σελίδας
        String url = "http://" + myIP + "/physiotherapp/getAppointments.php?id=" + centerID;
        TableLayout tableLayout = findViewById(R.id.tableDataLayout);

        try{
            OkHttpHandler okHttpHandler = new OkHttpHandler();
            appointments = okHttpHandler.getAppointments(url);

            for (Appointment appointment : appointments) {
                TableRow tableRow = new TableRow(this);
                tableRow.setLayoutParams(new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));

                String name = appointment.getPatientName();
                String date = appointment.getDate() + "\n" + appointment.getTime();
                String mobile = appointment.getMobile();

                //δυναμική δημιουργία αντικειμένων για να μπουν στο table row
                //3 text views και  1 linearlayout που θα εχει τα 2 image buttons εμφωλευμένα
                TextView nameTextView = createDataCell(name, 3);
                TextView dateTextView = createDataCell(date, 2);
                TextView mobileTextView = createDataCell(mobile, 3);

                LinearLayout linearLayout = new LinearLayout(this);
                linearLayout.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT, 1));
                linearLayout.setOrientation(LinearLayout.HORIZONTAL);

                ImageButton yesImgButton = new ImageButton(this);
                LinearLayout.LayoutParams yesLayoutParams = new LinearLayout.LayoutParams(
                        dpToPx(20),
                        dpToPx(30)
                );
                yesLayoutParams.weight = 1;
                yesImgButton.setLayoutParams(yesLayoutParams);
                yesImgButton.setAdjustViewBounds(true);
                yesImgButton.setBackgroundTintList(ContextCompat.getColorStateList(this, android.R.color.white));
                yesImgButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        acceptAppointment(appointment.getAppointmentId());
                        recreate();
                    }
                });
                yesImgButton.setPadding(dpToPx(5), dpToPx(5), dpToPx(5), dpToPx(5));
                yesImgButton.setScaleType(ImageView.ScaleType.FIT_CENTER);
                yesImgButton.setImageResource(R.drawable.yes);

                ImageButton noImgButton = new ImageButton(this);
                LinearLayout.LayoutParams noLayoutParams = new LinearLayout.LayoutParams(
                        dpToPx(20),
                        dpToPx(30)
                );
                noLayoutParams.weight = 1;
                noImgButton.setLayoutParams(noLayoutParams);
                noImgButton.setAdjustViewBounds(true);
                noImgButton.setBackgroundTintList(ContextCompat.getColorStateList(this, android.R.color.white));
                noImgButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        declineAppointment(appointment.getAppointmentId());
                        recreate();
                    }
                });
                noImgButton.setPadding(dpToPx(5), dpToPx(5), dpToPx(5), dpToPx(5));
                noImgButton.setScaleType(ImageView.ScaleType.FIT_CENTER);
                noImgButton.setImageResource(R.drawable.no);

                //προσθήκη εικόνων στο linear layout
                linearLayout.addView(yesImgButton);
                linearLayout.addView(noImgButton);

                //προσθήκη textviews στο table row
                tableRow.addView(nameTextView);
                tableRow.addView(dateTextView);
                tableRow.addView(mobileTextView);
                tableRow.addView(linearLayout);

                //προσθήκη table row στο table
                tableLayout.addView(tableRow);
            }
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    // μέθοδος για δημιουργία textview με τις κατάλληλες παραμέτρους
    private TextView createDataCell(String text, int layoutWeight) {
        TextView textView = new TextView(this);
        textView.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, layoutWeight));
        textView.setText(text);
        textView.setPadding(5,5,5,5);
        textView.setGravity(Gravity.CENTER);
        return textView;
    }

    //μέθοδος για κλήση setAppointment.php σε περίπτωση αποδοχής αιτήματος. Ορίζει το appointmentStatus = 1
    public void acceptAppointment(String appointmentId) {
        int status = 1;
        String url= "http://"+myIP+"/physiotherapp/setAppointmentStatus.php?id=" + appointmentId +  "&appointment_status=" + status;
        try {
            OkHttpHandler okHttpHandler = new OkHttpHandler();
            okHttpHandler.setAppointmentStatus(url);
            Toast.makeText(getApplicationContext(), "Αποδεχτήκατε το ραντεβού",
                    Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //μέθοδος για κλήση setAppointment.php σε περίπτωση απόρριψης αιτήματος . Ορίζει το appointmentStatus = 0
    public void declineAppointment(String appointmentId) {
        int status = 0;
        String url= "http://"+myIP+"/physiotherapp/setAppointmentStatus.php?id=" + appointmentId +  "&appointment_status=" + status;
        try {
            OkHttpHandler okHttpHandler = new OkHttpHandler();
            okHttpHandler.setAppointmentStatus(url);
            Toast.makeText(getApplicationContext(), "Απορρίψατε το ραντεβού",
                    Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //μέθοδος για μετατροπή dp σε px
    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }


}