package com.example.r7;

public class Appointment {


    private String appointmentId;
    private String patientName;
    private String mobile;
    private String date;
    private String time;
    private String appointmentStatus;


    public Appointment(String appointmentId, String patientName, String mobile, String date, String time, String appointmentStatus){
       this.appointmentId = appointmentId;
       this.patientName = patientName;
       this.mobile = mobile;
       this.date = date;
       this.time = time;
       this.appointmentStatus = appointmentStatus;
    }

    public Appointment(String appointmentId, String time, String patientName){
        this.appointmentId = appointmentId;
        this.time = time;
        this.patientName = patientName;

    }

    public String getAppointmentId() { return appointmentId; }
    public String getPatientName(){
        return patientName;
    }
    public String getMobile(){
        return mobile;
    }
    public String getDate() {
        return date;
    }
    public String getTime() {
        return time;
    }

    public String getAppointmentStatus() {
        return appointmentStatus;
    }

}
