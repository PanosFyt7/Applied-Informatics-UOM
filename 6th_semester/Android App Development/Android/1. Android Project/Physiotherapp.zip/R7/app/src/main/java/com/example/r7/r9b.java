package com.example.r7;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TextView;

public class r9b extends AppCompatActivity {
    private SharedPreferences sharedPreferences;
    private CheckBox checkBox3, checkBox4, checkBox6, checkBox7, checkBox8, checkBox9;
    private TextView textView10, textView11, textView12, textView13, textView14, textView15;
    private Spinner spinner;
    private String checkedCheckboxText;
    private int visitCount;

    String selectedCenterID = "";
    String selectedName = "";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // requestWindowFeature(Window.FEATURE_NO_TITLE);
        // this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_r9b);

        Intent intent = getIntent();
        String phone = intent.getStringExtra("phone_num");
        String day = intent.getStringExtra("day");
        String month = intent.getStringExtra("month");
        String year = intent.getStringExtra("year");
        int fores = intent.getIntExtra("fores", 0);
        String patientName = intent.getStringExtra("NAME");
        int patientID = intent.getIntExtra("ID", 0);

        String selectedCenterID = intent.getStringExtra("physioID");
        String selectedName = intent.getStringExtra("physioName");;

        String checkedCheckboxText = intent.getStringExtra("checkedCheckboxText");

        //λειτουργικότητα για το home button
        ImageButton homeButton = findViewById(R.id.homeImgButton);
        homeButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r9b.this, PatientHome.class);
                intent.putExtra("NAME", patientName);
                intent.putExtra("ID", patientID);
                startActivity(intent);
            }
        });


        //λειτουργικότητα για το logoff Button
        Button logoffButton = findViewById(R.id.logOffBtn);
        logoffButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r9b.this, LogIn.class);
                startActivity(intent);
            }
        });

        // Retrieve the visit count from SharedPreferences
        sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        visitCount = sharedPreferences.getInt("visitCount", 0);

        TableLayout tableLayout = findViewById(R.id.tableLayout);
        tableLayout.setShowDividers(TableLayout.SHOW_DIVIDER_MIDDLE);
        tableLayout.setDividerDrawable(ContextCompat.getDrawable(this, R.drawable.table_divider));

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);

        // Get references to the checkboxes
        checkBox3 = findViewById(R.id.checkBox3);
        checkBox4 = findViewById(R.id.checkBox4);
        checkBox6 = findViewById(R.id.checkBox6);
        checkBox7 = findViewById(R.id.checkBox7);
        checkBox8 = findViewById(R.id.checkBox8);
        checkBox9 = findViewById(R.id.checkBox9);

        textView10 = findViewById(R.id.textView10);
        textView11 = findViewById(R.id.textView11);
        textView12 = findViewById(R.id.textView12);
        textView13 = findViewById(R.id.textView13);
        textView14 = findViewById(R.id.textView14);
        textView15 = findViewById(R.id.textView15);

        spinner = findViewById(R.id.spinner);

        if(fores == 0) {
            // Set the initial state of checkboxes to unchecked
            checkBox3.setChecked(false);
            checkBox4.setChecked(false);
            checkBox6.setChecked(false);
            checkBox7.setChecked(false);
            checkBox8.setChecked(false);
            checkBox9.setChecked(false);
        }else {
            // Restore the checked state of checkboxes
            checkBox3.setChecked(sharedPreferences.getBoolean("checkBox3State", false));
            checkBox4.setChecked(sharedPreferences.getBoolean("checkBox4State", false));
            checkBox6.setChecked(sharedPreferences.getBoolean("checkBox6State", false));
            checkBox7.setChecked(sharedPreferences.getBoolean("checkBox7State", false));
            checkBox8.setChecked(sharedPreferences.getBoolean("checkBox8State", false));
            checkBox9.setChecked(sharedPreferences.getBoolean("checkBox9State", false));
        }

        // Increment the visit count
        visitCount++;

        // Store the updated visit count in SharedPreferences
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("visitCount", visitCount);
        editor.apply();

        // Set the OnCheckedChangeListener for each checkbox
        checkBox3.setOnCheckedChangeListener(checkBoxChangeListener);
        checkBox4.setOnCheckedChangeListener(checkBoxChangeListener);
        checkBox6.setOnCheckedChangeListener(checkBoxChangeListener);
        checkBox7.setOnCheckedChangeListener(checkBoxChangeListener);
        checkBox8.setOnCheckedChangeListener(checkBoxChangeListener);
        checkBox9.setOnCheckedChangeListener(checkBoxChangeListener);

        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Code to execute when the button is clicked
                openFirstActivity();
            }

            private void openFirstActivity() {
                Intent intent = new Intent(r9b.this, r9a.class);
                int fores = 1;
                intent.putExtra("fores",fores);
                intent.putExtra("phone_num",phone);
                intent.putExtra("day",day);
                intent.putExtra("month",month);
                intent.putExtra("year",year);
                intent.putExtra("fores", fores);
                intent.putExtra("NAME", patientName);
                intent.putExtra("ID", patientID);

                intent.putExtra("physioName", selectedName);
                intent.putExtra("physioID", selectedCenterID);

                // Set the value of checkedCheckboxText based on the checked checkboxes
                final String finalCheckedCheckboxText;

                if (checkBox3.isChecked()) {
                    finalCheckedCheckboxText = textView10.getText().toString();
                } else if (checkBox4.isChecked()) {
                    finalCheckedCheckboxText = textView11.getText().toString();
                } else if (checkBox6.isChecked()) {
                    finalCheckedCheckboxText = textView12.getText().toString();
                } else if(checkBox7.isChecked()){
                    finalCheckedCheckboxText = textView13.getText().toString();
                } else if(checkBox8.isChecked()) {
                    finalCheckedCheckboxText = textView14.getText().toString();
                }else if(checkBox9.isChecked()) {
                    finalCheckedCheckboxText = textView15.getText().toString();
                } else {
                    finalCheckedCheckboxText = null; // Set it to null if no checkbox is checked
                }

                intent.putExtra("checked_checkbox_text", finalCheckedCheckboxText); // Pass the checked checkbox text
                startActivity(intent);
            }
        });
    }

    // OnCheckedChangeListener for checkboxes
    CompoundButton.OnCheckedChangeListener checkBoxChangeListener = new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            // Store the checked state of the checkbox
            SharedPreferences.Editor editor = sharedPreferences.edit();
            switch (buttonView.getId()) {
                case R.id.checkBox3:
                    editor.putBoolean("checkBox3State", isChecked);
                    if (isChecked) {
                        checkedCheckboxText = textView10.getText().toString();
                    }
                    break;
                case R.id.checkBox4:
                    editor.putBoolean("checkBox4State", isChecked);
                    if (isChecked) {
                        checkedCheckboxText = textView11.getText().toString();
                    }
                    break;
                case R.id.checkBox6:
                    editor.putBoolean("checkBox6State", isChecked);
                    if (isChecked) {
                        checkedCheckboxText = textView12.getText().toString();
                    }
                    break;
                case R.id.checkBox7:
                    editor.putBoolean("checkBox7State", isChecked);
                    if (isChecked) {
                        checkedCheckboxText = textView13.getText().toString();
                    }
                    break;
                case R.id.checkBox8:
                    editor.putBoolean("checkBox8State", isChecked);
                    if (isChecked) {
                        checkedCheckboxText = textView14.getText().toString();
                    }
                    break;
                case R.id.checkBox9:
                    editor.putBoolean("checkBox9State", isChecked);
                    if (isChecked) {
                        checkedCheckboxText = textView15.getText().toString();
                    }
                    break;
            }
            editor.apply();
        }
    };
}
