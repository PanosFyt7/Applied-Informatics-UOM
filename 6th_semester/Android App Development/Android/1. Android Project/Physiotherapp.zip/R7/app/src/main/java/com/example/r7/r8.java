package com.example.r7;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class r8 extends AppCompatActivity {


    private final String myIP = "192.168.1.8";

    ArrayList<Provision> provisions = new ArrayList<Provision>();
    ArrayList<Appointment> appointments = new ArrayList<Appointment>();
    String appointmentID;
    String provisionID;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); // κρύβει το του banner τίτλου
        setContentView(R.layout.activity_r8);

        Intent intent = getIntent();
        String centerName = intent.getStringExtra("NAME");
        int centerID = intent.getIntExtra("ID", 0);

        hideViews();

        //λειτουργικότητα για το home button
        ImageButton homeButton = findViewById(R.id.homeImgButton);
        homeButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r8.this, CenterHome.class);
                intent.putExtra("NAME", centerName);
                intent.putExtra("ID", centerID);
                startActivity(intent);
            }
        });

        //λειτουργικότητα για το logoff Button
        Button logoffButton = findViewById(R.id.logOffBtn);
        logoffButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r8.this, LogIn.class);
                startActivity(intent);
            }
        });

        //διαδικασία για να φέρνει τα provisions και να τα βάζει στο spinner με το κλικ της ημερομηνίας
        ImageButton dateImageButton = findViewById(R.id.dateImageButton);
        dateImageButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                EditText editTextDate = findViewById(R.id.editTextDate);
                String date = editTextDate.getText().toString().trim();
                //SOS το format πρέπει να είναι τύπου"YYYY-MM-DD"
                if (date.isEmpty()) {
                    //do nothing
                } else {
                    Spinner provisionSpinner = findViewById(R.id.provisionSpinner);
                    String url = "http://" + myIP + "/physiotherapp/getProvisions.php";

                    try {
                        OkHttpHandler okHttpHandler = new OkHttpHandler();
                        provisions = okHttpHandler.getProvisions(url);
                        ArrayList<String> proNames = new ArrayList<String>();

                        for (Provision provision : provisions) {
                            String proName = provision.getProname();
                            proNames.add(proName);
                        }

                        //για να τα βάλει στο spinner
                        ArrayAdapter<String> adapter = new ArrayAdapter<>(r8.this, android.R.layout.simple_spinner_item, proNames);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        provisionSpinner.setAdapter(adapter);

                        provisionSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                String selectedName = parent.getSelectedItem().toString();

                                for (Provision provision : provisions) {
                                    if (provision.getProname().equals(selectedName)) {
                                        provisionID = provision.getId();
                                        break;
                                    }
                                }
                            }
                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {
                                // Handle the case where nothing is selected
                            }
                        });

                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                    //διαδικασία για να παίρνει την ημερομηνία από το edit text και να επιστρέφει τα ΑΠΟΔΕΚΤΑ ραντεβού του ιατρείου για εκείνη την ημέρα
                    Spinner appointmentSpinner = findViewById(R.id.appointmentSpinner);
                    String url2 = "http://" + myIP + "/physiotherapp/getDailyAppointments.php?centerID=" + centerID + "&date=" + date;

                    try {
                        OkHttpHandler okHttpHandler = new OkHttpHandler();
                        appointments = okHttpHandler.getDailyAppointments(url2);
                        ArrayList<String> appInfoList = new ArrayList<String>();

                        //ενωση ώρας με όνομα ασθενή
                        for (Appointment app : appointments) {
                            String appointmentInfo = app.getTime() + " " + app.getPatientName();
                            appInfoList.add(appointmentInfo);
                        }
                        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(r8.this, android.R.layout.simple_spinner_item, appInfoList);
                        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        appointmentSpinner.setAdapter(adapter2);

                        appointmentSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                String selectedName = parent.getSelectedItem().toString();

                                for (Appointment app : appointments) {
                                   String timeNameString = app.getTime() + " " + app.getPatientName();

                                    if (timeNameString.equals(selectedName)) {
                                        appointmentID = app.getAppointmentId();
                                        break;
                                    }
                                }
                            }
                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {
                                // Handle the case where nothing is selected
                            }
                        });
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    showViews();
                }
            }
        });

    }

    //με το κλικ του κουμπιού να καταχωρείται το session
    public void onCreateButtonClick(View view){
        EditText dateEditText = findViewById(R.id.editTextDate);
        Spinner appointmentSpinner = findViewById(R.id.appointmentSpinner);
        Spinner provisionSpinner = findViewById(R.id.provisionSpinner);
        EditText commentsEditText = findViewById(R.id.commentsEditText);


        String comments = commentsEditText.getText().toString();

        String url3 = "http://" + myIP + "/physiotherapp/createSession.php?comments=" + comments + "&provisionID=" + provisionID +
                "&appointmentID=" + appointmentID;
        try {
            OkHttpHandler okHttpHandler = new OkHttpHandler();
            okHttpHandler.createSession(url3);
            Toast.makeText(getApplicationContext(), "Καταχωρήθηκε η συνεδρία",
                    Toast.LENGTH_SHORT).show();
            dateEditText.setText("");
            commentsEditText.setText("");
            recreate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void showViews(){
        TextView appointmentTextView = findViewById(R.id.appointmentTextView);
        TextView provisionTextView = findViewById(R.id.provisionTextView);
        TextView commentTextView = findViewById(R.id.commentsTextView);
        Spinner appointmentSpinner = findViewById(R.id.appointmentSpinner);
        Spinner provisionSpinner = findViewById(R.id.provisionSpinner);
        EditText commentEditText = findViewById(R.id.commentsEditText);

        appointmentTextView.setVisibility(View.VISIBLE);
        provisionTextView.setVisibility(View.VISIBLE);
        commentTextView.setVisibility(View.VISIBLE);
        appointmentSpinner.setVisibility(View.VISIBLE);
        provisionSpinner.setVisibility(View.VISIBLE);
        commentEditText.setVisibility(View.VISIBLE);
    }

    public void hideViews(){
        TextView appointmentTextView = findViewById(R.id.appointmentTextView);
        TextView provisionTextView = findViewById(R.id.provisionTextView);
        TextView commentTextView = findViewById(R.id.commentsTextView);
        Spinner appointmentSpinner = findViewById(R.id.appointmentSpinner);
        Spinner provisionSpinner = findViewById(R.id.provisionSpinner);
        EditText commentEditText = findViewById(R.id.commentsEditText);

        appointmentTextView.setVisibility(View.GONE);
        provisionTextView.setVisibility(View.GONE);
        commentTextView.setVisibility(View.GONE);
        appointmentSpinner.setVisibility(View.GONE);
        provisionSpinner.setVisibility(View.GONE);
        commentEditText.setVisibility(View.GONE);
    }

}