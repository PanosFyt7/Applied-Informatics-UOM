package com.example.r7;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PSFHome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_psf_home);

        //λειτουργικότητα για το home button
        ImageButton homeButton = findViewById(R.id.homeImgButton);
        homeButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                recreate();
            }
        });

        //λειτουργικότητα για το logoff Button
        Button logoffButton = findViewById(R.id.logOffBtn);
        logoffButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(PSFHome.this, LogIn.class);
                startActivity(intent);
            }
        });

        //φέρνει το όνομα του Admin από το login intent και το βάζει στο textview
        TextView nameTextView = findViewById(R.id.PSFNameTextView);
        Intent intent = getIntent();
        String psfName = intent.getStringExtra("NAME");
        nameTextView.setText(psfName);

        //λειτουργικότητα για το R1 Button
        Button r1Button = findViewById(R.id.r1Button);
        r1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the new activity here
                Intent intent = new Intent(PSFHome.this, r1.class);
                intent.putExtra("NAME", psfName);
                startActivity(intent);
            }
        });

        //λειτουργικότητα για το R2 Button
        Button r2Button = findViewById(R.id.r2Button);
        r2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the new activity here
                Intent intent = new Intent(PSFHome.this, r2.class);
                intent.putExtra("NAME", psfName);
                startActivity(intent);
            }
        });
    }

}
