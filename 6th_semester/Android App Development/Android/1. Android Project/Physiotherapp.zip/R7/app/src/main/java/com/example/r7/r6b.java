package com.example.r7;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;

public class r6b extends AppCompatActivity {

    private final String myIP = "192.168.1.8";
    private ArrayList<Appointment> appointments = new ArrayList<Appointment>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); // κρύβει το του banner τίτλου
        setContentView(R.layout.activity_r6b);

        TextView dateTextView = findViewById(R.id.dateTextView);

        Intent intent = getIntent();
        String centerName = intent.getStringExtra("NAME");
        int centerID = intent.getIntExtra("ID", 0);
        String date = intent.getStringExtra("DATE");



        dateTextView.setText(date);

        //λειτουργικότητα για το home button
        ImageButton homeButton = findViewById(R.id.homeImgButton);
        homeButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r6b.this, CenterHome.class);
                intent.putExtra("NAME", centerName);
                intent.putExtra("ID", centerID);
                startActivity(intent);
            }
        });

        //λειτουργικότητα για το logoff Button
        Button logoffButton = findViewById(R.id.logOffBtn);
        logoffButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r6b.this, LogIn.class);
                startActivity(intent);
            }
        });

        String url = "http://" + myIP + "/physiotherapp/getAppointmentPlan.php?centerID=" + centerID + "&date=" + date;
        System.out.println(url);
        TableLayout tableLayout = findViewById(R.id.tableDataLayout);

        try{
            OkHttpHandler okHttpHandler = new OkHttpHandler();
            appointments = okHttpHandler.getAppointmentPlan(url);

            //για κάθε αντικείμενο που πήραμε απο τη βάση, φτιάξε μια γραμμή
            for (Appointment appointment : appointments) {
                TableRow tableRow = new TableRow(this);
                tableRow.setLayoutParams(new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));

                String name = appointment.getPatientName();
                String time = appointment.getTime();

                //δυναμική δημιουργία αντικειμένων για να μπουν στο table row
                TextView nameTextView = createDataCell(name, 1);
                TextView timeTextView = createDataCell(time, 1);

                //προσθήκη textviews στο table row
                tableRow.addView(nameTextView);
                tableRow.addView(timeTextView);

                //προσθήκη table row στο table
                tableLayout.addView(tableRow);
            }
        } catch(Exception e){
            e.printStackTrace();

        }
    }

    private TextView createDataCell(String text, int layoutWeight) {
        TextView textView = new TextView(this);
        textView.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, layoutWeight));
        textView.setText(text);
        textView.setPadding(5,5,5,5);
        textView.setGravity(Gravity.CENTER);
        return textView;
    }
}