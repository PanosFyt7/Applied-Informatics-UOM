package com.example.r7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LogIn extends AppCompatActivity {

    private final String myIP = "192.168.1.8";
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); // krivei to  title banner
        setContentView(R.layout.activity_log_in);
        EditText usernameEditText = findViewById(R.id.usernameEditText);
        EditText passEditText = findViewById(R.id.passwordEditText);

        //λειτουργικότητα του login button
        Button loginButton = findViewById(R.id.loginButton);
        loginButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent;
                String username = String.valueOf(usernameEditText.getText());
                String password = String.valueOf(passEditText.getText());

                String url= "http://"+myIP+"/physiotherapp/checkCredentials.php?username=" + username +  "&password=" + password;
                    try {
                        OkHttpHandler okHttpHandler = new OkHttpHandler();
                        user = okHttpHandler.checkCredentials(url);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    //αν είναι ο ρόλος 0, δηλαδή administrator, τότε πάει στην αρχική του ΠΣΦ
                    if (user.getIdRole() == 0){
                        intent = new Intent(LogIn.this, PSFHome.class);
                        intent.putExtra("NAME", user.getName() );
                        startActivity(intent);
                    }
                    //αν είναι ο ρόλος 1, δηλαδή Ιατρείο, τότε πάει στην αρχική του Ιατρείου και δίνει και το ID του
                    else if (user.getIdRole() == 1){
                        intent = new Intent(LogIn.this, CenterHome.class);
                        intent.putExtra("NAME", user.getName());
                        intent.putExtra("ID", user.getId());
                        startActivity(intent);
                    }
                    //αν είναι ο ρόλος 2, δηλαδή ασθενής, τότε πάει στην αρχική του Ασθενή
                    else if (user.getIdRole() == 2){
                        intent = new Intent(LogIn.this, PatientHome.class);
                        intent.putExtra("NAME", user.getName());
                        intent.putExtra("ID", user.getId());
                        startActivity(intent);
                    }
                    else{
                        Toast.makeText(getApplicationContext(), "Το username ή το password είναι λάθος",
                                Toast.LENGTH_LONG).show();
                    }
                }
                });

        //λειτουργικότητα για το register button
        Button registerButton = findViewById(R.id.registerButton);
        registerButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(LogIn.this, Register.class);
                startActivity(intent);
            }
        });
    }
}