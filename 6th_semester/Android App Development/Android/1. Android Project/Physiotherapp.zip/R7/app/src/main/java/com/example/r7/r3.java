package com.example.r7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

public class r3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); // κρύβει το του banner τίτλου
        setContentView(R.layout.activity_r3);

        Intent intent = getIntent();
        String centerName = intent.getStringExtra("NAME");
        int centerID = intent.getIntExtra("ID", 0);

        //λειτουργικότητα για το home button
        ImageButton homeButton = findViewById(R.id.homeImgButton);
        homeButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r3.this, CenterHome.class);
                intent.putExtra("NAME", centerName);
                intent.putExtra("ID", centerID);
                startActivity(intent);
            }
        });

        //λειτουργικότητα για το logoff Button
        Button logoffButton = findViewById(R.id.logOffBtn);
        logoffButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r3.this, LogIn.class);
                startActivity(intent);
            }
        });
    }


    public void onCreateButtonClick(View view) {
        // Get the data from the EditText
        EditText nameText = findViewById(R.id.name);
        EditText addressText = findViewById(R.id.address);
        EditText amkaText = findViewById(R.id.amka);
        EditText phoneText = findViewById(R.id.phone);
        EditText emailText = findViewById(R.id.email);

        String nameData = nameText.getText().toString();
        String addressData = addressText.getText().toString();
        String amkaData = amkaText.getText().toString();
        String phoneData = phoneText.getText().toString();
        String emailData = emailText.getText().toString();

        // Pass the context when creating DataHelp instance
        DataHelp dataHelp = new DataHelp(r3.this);
        dataHelp.execute(nameData, addressData, amkaData, phoneData, emailData);
    }
}