package com.example.r7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class r2 extends AppCompatActivity {

    Button btn;
    String myIP = "192.168.1.8" ;
    EditText id_provision,proname,prodescription,cost;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); // κρύβει το του banner τίτλου
        setContentView(R.layout.activity_r2);

        Intent intent = getIntent();
        String psfName = intent.getStringExtra("NAME");

        btn = findViewById(R.id.button);
        id_provision = findViewById(R.id.Code_text);
        proname = findViewById(R.id.name_text);
        prodescription = findViewById(R.id.textInputEditText2);
        cost = findViewById(R.id.textInputEditText);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String url= "http://"+myIP+"/physiotherapp/createProvision.php?code=" + id_provision.getText() +
                        "&name=" + proname.getText() + "&description=" + prodescription.getText() + "&cost=" + cost.getText();
                try {
                    OkHttpHandler okHttpHandler = new OkHttpHandler();
                    okHttpHandler.createProvision(url);
                    Toast.makeText(getApplicationContext(), "Η νέα Παροχή προστέθηκε",
                            Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

        //λειτουργικότητα για το home button
        ImageButton homeButton = findViewById(R.id.homeImgButton);
        homeButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r2.this, PSFHome.class);
                intent.putExtra("NAME", psfName);
                startActivity(intent);
            }
        });

        //λειτουργικότητα για το logoff Button
        Button logoffButton = findViewById(R.id.logOffBtn);
        logoffButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r2.this, LogIn.class);
                startActivity(intent);
            }
        });
    }
}