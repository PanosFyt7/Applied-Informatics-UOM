package com.example.r7;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class r1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_r1);

        Intent intent = getIntent();
        String psfName = intent.getStringExtra("NAME");

        //λειτουργικότητα για το home button
        ImageButton homeButton = findViewById(R.id.homeImgButton);
        homeButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r1.this, PSFHome.class);
                intent.putExtra("NAME",psfName );
                startActivity(intent);
            }
        });

        //λειτουργικότητα για το logoff Button
        Button logoffButton = findViewById(R.id.logOffBtn);
        logoffButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r1.this, LogIn.class);
                startActivity(intent);
            }
        });
    }

    public void onInsertButtonClick(View view) {

        // Get the data from the EditText
        EditText nameText = findViewById(R.id.name);
        EditText addressText = findViewById(R.id.address);
        EditText afmText = findViewById(R.id.afm);
        EditText usernameText = findViewById(R.id.username);
        EditText passwordText = findViewById(R.id.password);

        String nameData = nameText.getText().toString();
        String addressData = addressText.getText().toString();
        String afmData = afmText.getText().toString();
        String usernameData = usernameText.getText().toString();
        String passwordData = passwordText.getText().toString();

        //new InsertDataAsyncTask().execute(nameData, addressData, afmData);
        new InsertDataAsyncTask().execute(nameData, addressData, afmData, usernameData, passwordData);

        // Example: Display a Toast message
        Toast.makeText(this, "Το ιατρείο προστέθηκε με επιτυχία", Toast.LENGTH_SHORT).show();
    }
}