package com.example.r7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class PatientHome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        getSupportActionBar().hide(); // krivei to  title banner
        setContentView(R.layout.activity_patient_home);

        //φέρνει το όνομα του ασθενή από το login intent και το βάζει στο textview
        TextView nameTextView = findViewById(R.id.patientNameTextView);
        Intent intent = getIntent();
        String patientName = intent.getStringExtra("NAME");
        int patientID = intent.getIntExtra("ID", 0);
        nameTextView.setText(patientName);

        //λειτουργικότητα για το home button
        ImageButton homeButton = findViewById(R.id.homeImgButton);
        homeButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                recreate();
            }
        });

        //λειτουργικότητα για το logoff Button
        Button logoffButton = findViewById(R.id.logOffBtn);
        logoffButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(PatientHome.this, LogIn.class);
                startActivity(intent);
            }
        });

        //λειτουργικότητα  r9 button
        Button r9Button = findViewById(R.id.r9Button);
        r9Button.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(PatientHome.this, r9a.class);
                intent.putExtra("NAME", patientName);
                intent.putExtra("ID", patientID);
                startActivity(intent);
            }
        });

        //λειτουργικότητα  r10 button
        Button r10Button = findViewById(R.id.r10Button);
        r10Button.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(PatientHome.this, r10.class);
                intent.putExtra("NAME", patientName);
                intent.putExtra("ID", patientID);
                startActivity(intent);
            }
        });


    }
}