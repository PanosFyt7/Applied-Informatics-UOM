package com.example.r7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.app.DatePickerDialog;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import java.util.Calendar;

public class r6a extends AppCompatActivity {

    private DatePickerDialog datePickerDialog;
    private Button dateButton;
    private int centerID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); // κρύβει το του banner τίτλου
        setContentView(R.layout.activity_r6a);
        initDatePicker();
        dateButton = findViewById(R.id.datePickerButton);
        dateButton.setText(getTodaysDate());

        Intent intent = getIntent();
        String centerName = intent.getStringExtra("NAME");
        centerID = intent.getIntExtra("ID", 0);

        //EditText dateEditText = findViewById(R.id.editTextDate) ;


        //λειτουργικότητα για το home button
        ImageButton homeButton = findViewById(R.id.homeImgButton);
        homeButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r6a.this, CenterHome.class);
                intent.putExtra("NAME", centerName);
                intent.putExtra("ID", centerID);
                startActivity(intent);
            }
        });

        //λειτουργικότητα για το logoff Button
        Button logoffButton = findViewById(R.id.logOffBtn);
        logoffButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r6a.this, LogIn.class);
                startActivity(intent);
            }
        });


//        Button showAppointments = findViewById(R.id.showAppointments);
//        showAppointments.setOnClickListener(new View.OnClickListener(){
//            public void onClick(View v){
//                String date = dateEditText.getText().toString();
//                Intent intent = new Intent(r6a.this, r6b.class);
//                intent.putExtra("ID", centerID);
//                intent.putExtra("DATE", date);
//                startActivity(intent);
//            }
//        });


    }

    private String getTodaysDate() {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        month = month + 1;
        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
        return makeDateString(dayOfMonth, month, year);
    }

    private void initDatePicker() {
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;
                String date = makeDateString(year, month,dayOfMonth);
                displayAppointments(date);
            }
        };
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
        datePickerDialog = new DatePickerDialog(this, dateSetListener, year, month, dayOfMonth);
    }

    private String makeDateString(int year, int month, int dayOfMonth) {
        return  year + "-" + getMonthFormat(month) + "-" + dayOfMonth;
    }

    private String getMonthFormat(int month) {
        String[] months = {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"};
        if (month >= 1 && month <= 12) {
            return months[month - 1];
        }
        return "01";
    }

    public void openDatePicker(View view) {
        datePickerDialog.show();
    }

    private void displayAppointments(String selectedDate) {
        // Open the second activity and pass the selected date
        Intent intent = new Intent(r6a.this, r6b.class);
        intent.putExtra("ID", centerID);
        intent.putExtra("DATE", selectedDate);
        startActivity(intent);
    }
}