package com.example.r7;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

public class r5a extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); // κρύβει το του banner τίτλου
        setContentView(R.layout.activity_r5a);

        Intent intent = getIntent();
        String centerName = intent.getStringExtra("NAME");
        int centerID = intent.getIntExtra("ID", 0);

        Button button = findViewById(R.id.searchButton);
        EditText amka_textfield = findViewById(R.id.amkaTextField);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "http://192.168.1.8/physiotherapp/getPatient.php";
                String amka = amka_textfield.getText().toString();
                // Κατασκευή του αντικειμένου JSON με τα δεδομένα που θέλετε να στείλετε
                JSONObject postData = new JSONObject();
                try {
                    postData.put("amka", amka);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Log.d("JSON", postData.toString());
                JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, postData,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                // Αντιμετωπίστε την απόκριση JSON
                                try {
                                    if(!response.has("error")) {
                                        // Ανάκτηση των δεδομένων JSON
                                        String name = response.getString("name");
                                        String amka = response.getString("amka");
                                        String address = response.getString("address");
                                        String mobile = response.getString("phonenumber");
                                        String email = response.getString("email");
                                        Log.d("response", name);
                                        Intent intent = new Intent(r5a.this, r5b.class);
                                        intent.putExtra("patientName", name);
                                        intent.putExtra("amka", amka);
                                        intent.putExtra("address", address);
                                        intent.putExtra("mobile", mobile);
                                        intent.putExtra("email", email);
                                        intent.putExtra("NAME", centerName);
                                        intent.putExtra("ID", centerID);
                                        startActivity(intent);
                                        // Χρήση των δεδομένων
                                        // Εδώ μπορείτε να ενημερώσετε τη διεπαφή χρήστη με τα δεδομένα JSON
                                    } else {
                                        String error = response.getString("error");
                                        TextView patient_name = findViewById(R.id.Error);
                                        patient_name.setText(error);
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                // Αντιμετωπίστε το σφάλμα
                                error.printStackTrace();
                            }
                        });
                RequestQueue queue = Volley.newRequestQueue(r5a.this.getApplicationContext());
                queue.add(request);
            }
        });

        //λειτουργικότητα για το home button
        ImageButton homeButton = findViewById(R.id.homeImgButton);
        homeButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r5a.this, CenterHome.class);
                intent.putExtra("NAME", centerName);
                intent.putExtra("ID", centerID);
                startActivity(intent);
            }
        });

        //λειτουργικότητα για το logoff Button
        Button logoffButton = findViewById(R.id.logOffBtn);
        logoffButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r5a.this, LogIn.class);
                startActivity(intent);
            }
        });
    }


}