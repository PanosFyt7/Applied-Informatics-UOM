package com.example.r7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class CenterHome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); // krivei to  title banner
        setContentView(R.layout.activity_doctor_home);

        //φέρνει το όνομα του ιατρείου και το id του από το login intent και το βάζει στο textview
        TextView nameTextView = findViewById(R.id.physioCenterNameTextView);
        Intent intent = getIntent();
        String patientName = intent.getStringExtra("NAME");
        int centerID = intent.getIntExtra("ID", 0);
        nameTextView.setText(patientName);

        //λειτουργικότητα για το home button
        ImageButton homeButton = findViewById(R.id.homeImgButton);
        homeButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                recreate();
            }
        });

        //leitourgikotita tou logoff Button
        Button logoffButton = findViewById(R.id.logOffBtn);
        logoffButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(CenterHome.this, LogIn.class);
                startActivity(intent);
            }
        });

        //λειτουργικότητα  r3 button
        Button r3Button = findViewById(R.id.r3Button);
        r3Button.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(CenterHome.this, r3.class);
                intent.putExtra("NAME", patientName);
                intent.putExtra("ID", centerID);
                startActivity(intent);
            }
        });

        //λειτουργικότητα  r4 button
        Button r4Button = findViewById(R.id.r4Button);
        r4Button.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(CenterHome.this, r4.class);
                intent.putExtra("NAME", patientName);
                intent.putExtra("ID", centerID);
                startActivity(intent);
            }
        });

        //λειτουργικότητα  r5 button
        Button r5Button = findViewById(R.id.r5Button);
        r5Button.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(CenterHome.this, r5a.class);
                intent.putExtra("NAME", patientName);
                intent.putExtra("ID", centerID);
                startActivity(intent);
            }
        });

        //λειτουργικότητα  r6 button
        Button r6Button = findViewById(R.id.r6Button);
        r6Button.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(CenterHome.this, r6a.class);
                intent.putExtra("NAME", patientName);
                intent.putExtra("ID", centerID);
                startActivity(intent);
            }
        });

        //λειτουργικότητα  r7 button - εμφανίζει την λίστα των αιτημάτων ραντεβού που έχουν γίνει στο συγκεκριμένο ιατρείο
        //στέλνει και το ID του ιατρείου για να εμφανίσει ΜΟΝΟ τα ραντεβού του συγκεκριμένου ιατρείου
        Button r7Button = findViewById(R.id.r7Button);
        r7Button.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(CenterHome.this, r7.class);
                intent.putExtra("NAME", patientName);
                intent.putExtra("ID", centerID);
                startActivity(intent);
            }
        });

        //λειτουργικότητα  r8 button
        Button r8Button = findViewById(R.id.r8Button);
        r8Button.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(CenterHome.this, r8.class);
                intent.putExtra("NAME", patientName);
                intent.putExtra("ID", centerID);
                startActivity(intent);
            }
        });
    }
}