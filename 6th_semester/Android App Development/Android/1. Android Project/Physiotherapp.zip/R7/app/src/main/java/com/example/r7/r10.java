package com.example.r7;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;

public class r10 extends AppCompatActivity {


    private final String myIP = "192.168.1.8";

    ArrayList<Session> sessions = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); // κρύβει το του banner τίτλου
        setContentView(R.layout.activity_r10);

        Intent intent = getIntent();
        String patientName = intent.getStringExtra("NAME");
        int patientID = intent.getIntExtra("ID", 0);

        //λειτουργικότητα με το φόρτωμα της σελίδας
        String url = "http://" + myIP + "/physiotherapp/getEconomicHistory.php?id=" + patientID;
        TableLayout tableLayout = findViewById(R.id.tableDataLayout);

        try{
            OkHttpHandler okHttpHandler = new OkHttpHandler();
            sessions = okHttpHandler.getEconomicHistory(url);

            for (Session session : sessions) {
                TableRow tableRow = new TableRow(this);
                tableRow.setLayoutParams(new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));

                String date = session.getDate();
                String centerName = session.getCenterName();
                String provisionName = session.getProvisonName();
                String provisionCost = session.getProvisionCost();

                //δυναμική δημιουργία αντικειμένων για να μπουν στο table row
                //3 text views και  1 linearlayout που θα εχει τα 2 image buttons εμφωλευμένα
                TextView dateTextView = createDataCell(date, 2);
                TextView centerNameTextView = createDataCell(centerName, 2);
                TextView provisionNameTextView = createDataCell(provisionName, 2);
                TextView provisionCostTextView = createDataCell(provisionCost, 2);

                //προσθήκη textviews στο table row
                tableRow.addView(dateTextView);
                tableRow.addView(centerNameTextView);
                tableRow.addView(provisionNameTextView);
                tableRow.addView(provisionCostTextView);

                //προσθήκη table row στο table
                tableLayout.addView(tableRow);
            }
        } catch(Exception e){
            e.printStackTrace();
        }



        //λειτουργικότητα για το home button
        ImageButton homeButton = findViewById(R.id.homeImgButton);
        homeButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r10.this, PatientHome.class);
                intent.putExtra("NAME", patientName);
                startActivity(intent);
            }
        });

        //λειτουργικότητα για το logoff Button
        Button logoffButton = findViewById(R.id.logOffBtn);
        logoffButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(r10.this, LogIn.class);
                startActivity(intent);
            }
        });
    }

    // μέθοδος για δημιουργία textview με τις κατάλληλες παραμέτρους
    private TextView createDataCell(String text, int layoutWeight) {
        TextView textView = new TextView(this);
        textView.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, layoutWeight));
        textView.setText(text);
        textView.setPadding(5,5,5,5);
        textView.setGravity(Gravity.CENTER);
        return textView;
    }
}