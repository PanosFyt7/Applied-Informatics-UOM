package com.example.r7;

public class Session {

    private String sessionID;
    private String patientName;
    private String provisonName;
    private String provisionCost;
    private String date;
    private String centerName;

    public Session(String sessionID, String patientName, String provisionName, String provisionCost, String date){
        this.sessionID = sessionID;
        this.patientName = patientName;
        this.provisonName = provisionName;
        this.provisionCost = provisionCost;
        this.date = date;
    }

    public Session(String sessionID, String patientName, String provisionName, String provisionCost, String date, String centerName){
        this.sessionID = sessionID;
        this.patientName = patientName;
        this.provisonName = provisionName;
        this.provisionCost = provisionCost;
        this.date = date;
        this.centerName = centerName;
    }

    public String getSessionID() {
        return sessionID;
    }

    public String getPatientName() {
        return patientName;
    }

    public String getProvisonName() {
        return provisonName;
    }

    public String getProvisionCost() {
        return provisionCost;
    }

    public String getDate() {
        return date;
    }

    public String getCenterName() {
        return centerName;
    }

}
